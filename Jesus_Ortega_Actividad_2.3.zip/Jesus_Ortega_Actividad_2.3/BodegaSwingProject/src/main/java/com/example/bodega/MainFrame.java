package com.example.bodega;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

public class MainFrame extends JFrame {
    private Inventario inventario;
    private DefaultListModel<String> listModel;
    private JList<String> list;

    public MainFrame() {
        super("Bodega - Gestión de Inventario");
        this.inventario = new Inventario();
        initComponents();
        setSize(700,400);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    private void initComponents() {
        JPanel top = new JPanel(new FlowLayout(FlowLayout.LEFT));
        JButton btnAgregar = new JButton("Agregar producto");
        JButton btnSumar = new JButton("Registrar entrada (sumar)");
        JButton btnRestar = new JButton("Registrar salida (restar)");
        JButton btnReporte = new JButton("Reportes");

        top.add(btnAgregar);
        top.add(btnSumar);
        top.add(btnRestar);
        top.add(btnReporte);

        listModel = new DefaultListModel<>();
        list = new JList<>(listModel);
        JScrollPane scroll = new JScrollPane(list);

        add(top, BorderLayout.NORTH);
        add(scroll, BorderLayout.CENTER);

        btnAgregar.addActionListener(this::onAgregarProducto);
        btnSumar.addActionListener(this::onSumarStock);
        btnRestar.addActionListener(this::onRestarStock);
        btnReporte.addActionListener(this::onReportes);

        // ejemplo inicial
        inventario.agregarProducto(new Producto("P-001", "Tornillos x100", 50, 10));
        inventario.agregarProducto(new Producto("P-002", "Tuercas x50", 20, 5));
        refrescarLista();
    }

    private void refrescarLista() {
        listModel.clear();
        for (Producto p : inventario.listarProductos()) {
            listModel.addElement(p.toString());
        }
    }

    private void onAgregarProducto(ActionEvent e) {
        JTextField idField = new JTextField(UUID.randomUUID().toString().substring(0,8));
        JTextField nombreField = new JTextField();
        JTextField stockField = new JTextField("0");
        JTextField umbralField = new JTextField("5");

        Object[] message = {
                "ID (se autogenera si dejas el campo):", idField,
                "Nombre:", nombreField,
                "Stock inicial:", stockField,
                "Umbral crítico:", umbralField
        };

        int option = JOptionPane.showConfirmDialog(this, message, "Agregar producto", JOptionPane.OK_CANCEL_OPTION);
        if (option == JOptionPane.OK_OPTION) {
            String id = idField.getText().trim();
            if (id.isEmpty()) id = "P-" + UUID.randomUUID().toString().substring(0,8);
            String nombre = nombreField.getText().trim();
            int stock = parseIntOrZero(stockField.getText());
            int umbral = parseIntOrZero(umbralField.getText());
            Producto p = new Producto(id, nombre, stock, umbral);
            inventario.agregarProducto(p);
            refrescarLista();
        }
    }

    private void onSumarStock(ActionEvent e) {
        String id = JOptionPane.showInputDialog(this, "Ingrese ID del producto a sumar stock (ej: P-001):");
        if (id == null) return;
        String qtyStr = JOptionPane.showInputDialog(this, "Cantidad a sumar:");
        if (qtyStr == null) return;
        int qty = parseIntOrZero(qtyStr);
        boolean ok = inventario.agregarStock(id.trim(), qty);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Stock agregado correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "Producto no encontrado.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        refrescarLista();
    }

    private void onRestarStock(ActionEvent e) {
        String id = JOptionPane.showInputDialog(this, "Ingrese ID del producto a restar stock (ej: P-001):");
        if (id == null) return;
        String qtyStr = JOptionPane.showInputDialog(this, "Cantidad a restar:");
        if (qtyStr == null) return;
        int qty = parseIntOrZero(qtyStr);
        boolean ok = inventario.restarStock(id.trim(), qty);
        if (ok) {
            JOptionPane.showMessageDialog(this, "Salida registrada correctamente.");
        } else {
            JOptionPane.showMessageDialog(this, "No hay stock suficiente o producto no existe.", "Error", JOptionPane.ERROR_MESSAGE);
        }
        refrescarLista();
    }

    private void onReportes(ActionEvent e) {
        int total = inventario.totalItemsEnInventario();
        List<Producto> criticos = inventario.productosCriticos();
        String criticosStr = criticos.stream().map(Producto::toString).collect(Collectors.joining("\n"));
        if (criticosStr.isEmpty()) criticosStr = "(no hay productos críticos)";
        String msg = "Total unidades en inventario: " + total + "\n\nProductos en stock crítico:\n" + criticosStr;
        JOptionPane.showMessageDialog(this, msg, "Reportes", JOptionPane.INFORMATION_MESSAGE);
    }

    private int parseIntOrZero(String s) {
        try { return Integer.parseInt(s.trim()); } catch (Exception ex) { return 0; }
    }
}
