package com.example.bodega;

public class Producto {
    private String id;
    private String nombre;
    private int stock;
    private int umbralCritico;

    public Producto(String id, String nombre, int stock, int umbralCritico) {
        this.id = id;
        this.nombre = nombre;
        this.stock = stock;
        this.umbralCritico = umbralCritico;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public int getStock() { return stock; }
    public int getUmbralCritico() { return umbralCritico; }

    public void setNombre(String nombre) { this.nombre = nombre; }
    public void setUmbralCritico(int umbralCritico) { this.umbralCritico = umbralCritico; }

    public void agregarStock(int cantidad) {
        if (cantidad <= 0) return;
        this.stock += cantidad;
    }

    /**
     * Intenta restar stock. Si no hay suficiente, no hace nada y devuelve false.
     */
    public boolean restarStock(int cantidad) {
        if (cantidad <= 0) return false;
        if (this.stock - cantidad < 0) return false;
        this.stock -= cantidad;
        return true;
    }

    @Override
    public String toString() {
        return id + " - " + nombre + " (stock: " + stock + ")";
    }
}
