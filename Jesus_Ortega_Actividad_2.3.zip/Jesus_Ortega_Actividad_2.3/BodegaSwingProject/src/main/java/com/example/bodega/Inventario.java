package com.example.bodega;

import java.util.ArrayList;
import java.util.List;

public class Inventario {
    private ArrayList<Producto> productos = new ArrayList<>();

    public void agregarProducto(Producto p) {
        productos.add(p);
    }

    public List<Producto> listarProductos() {
        return new ArrayList<>(productos);
    }

    public Producto buscarPorId(String id) {
        for (Producto p : productos) {
            if (p.getId().equals(id)) return p;
        }
        return null;
    }

    public boolean agregarStock(String id, int cantidad) {
        Producto p = buscarPorId(id);
        if (p == null) return false;
        p.agregarStock(cantidad);
        return true;
    }

    public boolean restarStock(String id, int cantidad) {
        Producto p = buscarPorId(id);
        if (p == null) return false;
        return p.restarStock(cantidad);
    }

    public int totalItemsEnInventario() {
        int total = 0;
        for (Producto p : productos) total += p.getStock();
        return total;
    }

    public List<Producto> productosCriticos() {
        List<Producto> criticos = new ArrayList<>();
        for (Producto p : productos) {
            if (p.getStock() <= p.getUmbralCritico()) criticos.add(p);
        }
        return criticos;
    }
}
