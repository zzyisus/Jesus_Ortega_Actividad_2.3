package com.example.bodega;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class BodegaTest {

    @Test
    public void testAgregarStock() {
        Inventario inv = new Inventario();
        Producto p = new Producto("X1", "Item", 7, 2);
        inv.agregarProducto(p);
        boolean ok = inv.agregarStock("X1", 5);
        assertTrue(ok);
        assertEquals(12, inv.buscarPorId("X1").getStock());
    }

    @Test
    public void testRestarStockExito() {
        Inventario inv = new Inventario();
        Producto p = new Producto("X2", "Item2", 10, 2);
        inv.agregarProducto(p);
        boolean ok = inv.restarStock("X2", 3);
        assertTrue(ok);
        assertEquals(7, inv.buscarPorId("X2").getStock());
    }

    @Test
    public void testRestarStockNoNegativo() {
        Inventario inv = new Inventario();
        Producto p = new Producto("X3", "Item3", 10, 2);
        inv.agregarProducto(p);
        boolean ok = inv.restarStock("X3", 11);
        assertFalse(ok, "No se debe permitir dejar stock negativo"); 
        assertEquals(10, inv.buscarPorId("X3").getStock());
    }
}
