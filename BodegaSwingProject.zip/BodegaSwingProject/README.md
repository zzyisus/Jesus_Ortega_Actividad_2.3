# Bodega Swing - Proyecto de ejemplo

Proyecto Java (Maven) con interfaz gráfica Swing para gestionar un inventario simple.

## Contenido
- src/main/java/com/example/bodega : código fuente
- src/test/java/com/example/bodega : pruebas JUnit (BodegaTest)
- pom.xml : configuración Maven (Java 11, JUnit Jupiter)

## Ejecutar
- Con un IDE (IntelliJ/NetBeans/Eclipse): abrir como proyecto Maven y ejecutar `com.example.bodega.Main`.
- En consola (maven): `mvn package` y luego ejecutar el jar si empaquetas uno, o `mvn exec:java` (requiere plugin exec).

## Notas
- La GUI es simple y funcional (Swing). Se generan dos productos de ejemplo al iniciar.
